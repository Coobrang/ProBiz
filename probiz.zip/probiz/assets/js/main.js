// Mobile Menu
console.clear();

const navExpand = document.querySelectorAll('.nav-expand');
const backLink = `<li class="nav-item"><a href="javascript:;" class="nav-link nav-back-link"><i class="fa-solid fa-caret-left"></i></a></li>`;

navExpand.forEach(item => {
    item.querySelector('.nav-expand-content').insertAdjacentHTML('afterbegin', backLink);
    const navLink = item.querySelector('.nav-link');
    navLink.addEventListener('click', () => item.classList.toggle('active'));
    item.querySelector('.nav-back-link').addEventListener('click', () => item.classList.remove('active'));
});

const hamIcon = document.getElementById('ham');
hamIcon.addEventListener('click', () => {
    document.body.classList.toggle('nav-is-toggled');
    hamIcon.innerHTML = (hamIcon.innerHTML === `<i class="fa-solid fa-bars"></i>`) ? `<i class="fa-solid fa-xmark"></i>` : `<i class="fa-solid fa-bars"></i>`;
});